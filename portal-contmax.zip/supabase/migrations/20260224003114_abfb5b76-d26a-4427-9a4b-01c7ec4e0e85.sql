ALTER TABLE public.honorarios_empresas
ADD COLUMN mes_inicial text NOT NULL DEFAULT 'janeiro';